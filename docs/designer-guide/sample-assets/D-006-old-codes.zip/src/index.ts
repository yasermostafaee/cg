import "./styles/main.scss"
//
import PanelClass from "./panels/panels"
import TimelineClass from "./panels/timeline"
import PreviewClass from "./panels/preview"
import Konva from "konva";

const PanelObject = new PanelClass({topContainerId: "topPanel", bottomContainerId: "bottomPanel", gutterId: "gutter"})

const PreviewObject = new PreviewClass({
    containerId: "preview",
    onAddShape: (shapeId: string) => TimelineObject.addLayer(shapeId),
    onTransformed: (node: Konva.Node) => TimelineObject.addPointByTransform(node),
})

const TimelineObject = new TimelineClass({
    containerId: "timeline",
    onTimelineUpdating: (data) => PreviewObject.playAnimation(data),
    onTimelineStop: PreviewObject.stopAnimation,
    onTimelineAddPoint: PreviewObject.addPoint,
    onTimelineRemovePoint: PreviewObject.removePoint,
    onTimelineUpdatePoint: PreviewObject.updatePoint,
})

document.getElementById('playPause')?.addEventListener('click', () => {
    const event = new Event("previewPlayPause");
    TimelineObject.playTimeBar();
});