import Konva from 'konva';
import {TTransformation} from './timeline.d';
import type {TShapeProps} from './preview.d';
import {TTransformPointType} from "./timeline.d";
import {TProperties} from "./timeline.d";

interface PreviewClassType {
    containerId: string;
    onAddShape: (shapeId: string) => void;
    onTransformed: (node: Konva.Node) => void;
}

export default class PreviewClass {
    private readonly stage: Konva.Stage;
    private readonly layer: Konva.Layer;
    private readonly tr: Konva.Transformer;
    private readonly selectionRect: Konva.Rect;
    private readonly onAddShape: (shapeId: string) => void;
    private readonly onTransformed: (node: Konva.Node) => void;
    private shapes: Konva.Node[] = [];
    private shapeCounter = 1;
    private anim: any = null;

    private readonly shapeColor = document.querySelector<HTMLElement>('.shapeColor');
    private readonly shapeColorInput = document.querySelector<HTMLInputElement>('.shapeColorInput');
    private readonly shapePositionXInput = document.querySelector<HTMLInputElement>('.shapePositionXInput');
    private readonly shapePositionYInput = document.querySelector<HTMLInputElement>('.shapePositionYInput');
    private readonly shapeWidthInput = document.querySelector<HTMLInputElement>('.shapeWidthInput');
    private readonly shapeHeightInput = document.querySelector<HTMLInputElement>('.shapeHeightInput');
    private readonly shapeRotationInput = document.querySelector<HTMLInputElement>('.shapeRotationInput');

    constructor({containerId, onAddShape, onTransformed}: PreviewClassType) {
        this.playAnimation = this.playAnimation.bind(this);
        this.stopAnimation = this.stopAnimation.bind(this);
        this.addPoint = this.addPoint.bind(this);
        this.removePoint = this.removePoint.bind(this);
        this.updatePoint = this.updatePoint.bind(this);

        this.onAddShape = onAddShape;
        this.onTransformed = onTransformed;
        const container = document.getElementById(containerId);
        const width = container?.offsetWidth ?? 800;
        const height = container?.offsetHeight ?? 600;

        this.stage = new Konva.Stage({container: containerId, width, height});
        this.layer = new Konva.Layer();
        this.stage.add(this.layer);

        this.tr = new Konva.Transformer({rotateEnabled: true});
        this.layer.add(this.tr);

        this.selectionRect = new Konva.Rect({
            fill: 'rgba(0,0,255,0.2)',
            visible: false,
        });
        this.layer.add(this.selectionRect);

        this.registerStageEvents();
        this.registerUIEvents();
        this.registerTransformListener();
    }

    // 🧩 Stage Event Registration
    private registerStageEvents() {
        this.stage.on('mousedown touchstart', (e) => this.onPointerDown(e));
        this.stage.on('mousemove touchmove', () => this.onPointerMove());
        this.stage.on('mouseup touchend', () => this.onPointerUp());
        this.stage.on('click tap', (e) => this.onPointerClick(e));
        // this.stage.on('dragmove', (e) => this.onDragMove(e));
        this.tr.on('dragmove', (e) => this.onDragMove(e));
        this.tr.on('dragend', (e) => this.onDragend(e));
    }

    // Handles shape resizing correctly
    private registerTransformListener() {
        this.tr.on('transformend', () => {

            console.log("transformend")
            // this.tr.nodes().forEach((node) => {
            //     node.setAttrs({
            //         width: node.width() * node.scaleX(),
            //         height: node.height() * node.scaleY(),
            //         scaleX: 1,
            //         scaleY: 1,
            //     });
            // });

            const node = this.tr.nodes()[0];
            node.setAttrs({
                width: node.width() * node.scaleX(),
                height: node.height() * node.scaleY(),
                scaleX: 1,
                scaleY: 1,
            });

            this.layer.batchDraw();
            this.onTransformed?.(node);
        });

        this.tr.on('transform', (e) => {
            this.tr.nodes().forEach((node) => {
                this.setShapeScale(node.width() * node.scaleX(), node.height() * node.scaleY(), node.rotation())
                this.checkExistPoint(this.tr.nodes()[0])
            });
        });
    }

    // UI controls (color and position inputs)
    private registerUIEvents() {
        const updateShapeAttr = (attr: string, value: any) => {
            const node = this.tr.nodes()[0];
            if (!node) return;
            node.setAttr(attr, value);
            this.layer.batchDraw();
            this.onTransformed?.(node);
        };

        this.shapeColorInput?.addEventListener('input', (e) => {
            updateShapeAttr('fill', (e.target as HTMLInputElement).value);
        });
        this.shapePositionXInput?.addEventListener('input', (e) => {
            updateShapeAttr('x', +((e.target as HTMLInputElement).value));
        });
        this.shapePositionYInput?.addEventListener('input', (e) => {
            updateShapeAttr('y', +((e.target as HTMLInputElement).value));
        });
        this.shapeWidthInput?.addEventListener('input', (e) => {
            updateShapeAttr('width', +((e.target as HTMLInputElement).value));
        });
        this.shapeHeightInput?.addEventListener('input', (e) => {
            updateShapeAttr('height', +((e.target as HTMLInputElement).value));
        });

        this.shapeRotationInput?.addEventListener('input', (e) => {
            updateShapeAttr('rotation', +((e.target as HTMLInputElement).value));
        });

        document.getElementById('addRectangle')?.addEventListener('click', () => this.addShape('rect'));
        document.getElementById('addCircle')?.addEventListener('click', () => this.addShape('circle'));
        document.getElementById('addText')?.addEventListener('click', () => this.addShape('text'));

        this.stage.container()?.addEventListener('shapeSelected', (e) => {
            const customEvent = e as CustomEvent<TShapeProps>;
            this.showShapeProperties(customEvent.detail);
        });
    }

    private addShape(type: 'rect' | 'circle' | 'text') {
        const id = `shape-${this.shapeCounter++}`;
        const commonAttrs = {
            fill: '#cccccc',
            name: 'selectable',
            id,
            draggable: true,
            points: [],
            subPoints: [],
        };

        let shape: Konva.Shape;

        switch (type) {
            case 'rect':
                shape = new Konva.Rect({...commonAttrs, x: 60, y: 60, width: 100, height: 90})
                break
            case 'circle':
                shape = new Konva.Circle({...commonAttrs, x: 100, y: 100, radius: 70})
                break
            case 'text':
                shape = new Konva.Text({
                    ...commonAttrs, x: 60, y: 60,width: 150, height: 50,
                    text: 'Simple Text',
                    fontSize: 30,
                    fontFamily: 'Calibri',
                    fill: 'white',
                })
                break

        }

        if (shape instanceof Konva.Text) {
            shape.on('dblclick dbltap', () => this.editTextNode(shape));
        }

        this.layer.add(shape);
        this.shapes.push(shape);
        this.layer.draw();
        this.onAddShape?.(id);
    }

    // Selection logic
    private x1 = 0;
    private y1 = 0;
    private x2 = 0;
    private y2 = 0;

    private editTextNode(textNode: Konva.Text) {
        const stage = this.stage;
        const layer = this.layer;

        textNode.hide();
        this.tr.hide();
        layer.draw();

        const textPosition = textNode.absolutePosition();
        const areaPosition = {
            x: stage.container().offsetLeft + textPosition.x,
            y: stage.container().offsetTop + textPosition.y
        };

        const textarea = document.createElement('textarea');
        document.body.appendChild(textarea);

        textarea.value = textNode.text();

        textarea.style.position = 'absolute';
        textarea.style.top = areaPosition.y + 'px';
        textarea.style.left = areaPosition.x + 'px';
        textarea.style.width = textNode.width() + 'px';
        textarea.style.minWidth = '150px';
        textarea.style.minHeight = textNode.width() + 'px';
        textarea.style.height = textNode.height() + 'px';
        textarea.style.fontSize = textNode.fontSize() + 'px';
        textarea.style.fontFamily = textNode.fontFamily();
        textarea.style.lineHeight = textNode.lineHeight().toString();
        textarea.style.color = String(textNode.fill());
        textarea.style.padding = '0px';
        textarea.style.margin = '0px';
        textarea.style.border = '1px solid #777';
        textarea.style.background = 'white';
        textarea.style.zIndex = '1000';

        textarea.focus();
        textarea.select();

        // ---- FIX: prevent double removal ----
        let removed = false;

        const removeTextarea = (save = true) => {
            if (removed) return; // prevents double execution
            removed = true;

            if (save) {
                textNode.text(textarea.value);
            }

            textarea.remove(); // instead of parentNode.removeChild

            textNode.show();
            this.tr.show();
            layer.draw();

            textarea.removeEventListener('blur', onBlur);
            textarea.removeEventListener('keydown', onKeydown);
        };

        const onBlur = () => removeTextarea(true);

        const onKeydown = (e: KeyboardEvent) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                removeTextarea(true);
            }
            if (e.key === 'Escape') {
                removeTextarea(false); // don't save changes
            }
        };

        textarea.addEventListener('blur', onBlur);
        textarea.addEventListener('keydown', onKeydown);
    }

    private onPointerDown(e: Konva.KonvaEventObject<MouseEvent | TouchEvent>) {
        if (e.target !== this.stage) return;
        const pos = this.stage.getPointerPosition();
        if (!pos) return;
        this.x1 = this.x2 = pos.x;
        this.y1 = this.y2 = pos.y;
        this.selectionRect.setAttrs({x: pos.x, y: pos.y, width: 0, height: 0, visible: true});
    }

    private onPointerMove() {
        if (!this.selectionRect.visible()) return;
        const pos = this.stage.getPointerPosition();
        if (!pos) return;
        this.x2 = pos.x;
        this.y2 = pos.y;
        this.selectionRect.setAttrs({
            x: Math.min(this.x1, this.x2),
            y: Math.min(this.y1, this.y2),
            width: Math.abs(this.x2 - this.x1),
            height: Math.abs(this.y2 - this.y1),
        });
    }

    private onPointerUp() {
        if (!this.selectionRect.visible()) return;
        setTimeout(() => this.selectionRect.visible(false));
        const box = this.selectionRect.getClientRect();
        const selected = this.stage
            .find('.rect,.circle,.text')
            .filter((shape) => Konva.Util.haveIntersection(box, shape.getClientRect()));
        this.tr.nodes(selected);
        this.layer.batchDraw();
    }

    private onPointerClick(e: Konva.KonvaEventObject<MouseEvent | TouchEvent>) {
        if (this.selectionRect.visible()) return;
        if (e.target === this.stage) {
            this.tr.nodes([]);
            return;
        }

        if (!e.target.hasName('selectable')) return;

        const evt = e.evt as MouseEvent;
        const meta = evt.shiftKey || evt.ctrlKey || evt.metaKey;
        const nodes = this.tr.nodes();
        const isSelected = nodes.includes(e.target);

        if (!meta && !isSelected) {
            this.tr.nodes([e.target]);
            this.dispatchShapeSelected(e.target);
        } else if (meta && isSelected) {
            this.tr.nodes(nodes.filter((n) => n !== e.target));
        } else if (meta && !isSelected) {
            this.tr.nodes([...nodes, e.target]);
        }
    }

    private onDragMove(e: Konva.KonvaEventObject<MouseEvent | TouchEvent>) {
        // if (this.tr.nodes().includes(e.target)) {

        this.setShapePositions(e.target.x(), e.target.y());

        // e.target is not a real node it's just a transformed node
        // this.checkExistPoint(this.tr.nodes()[0])
        // }
    }

    private onDragend(e: any) {
        // if (this.tr.nodes().includes(e.target)) {

        console.log("onDragend")

        const node = this.tr.nodes()[0];

        this.onTransformed?.(node);

        // console.log("foundPoint", foundPoint)

        // this.calcSubPoints2(node);
    }

    // Update side UI inputs when shape is selected
    private showShapeProperties(simpleShape: TShapeProps) {
        if (!this.shapeColorInput || !this.shapePositionXInput || !this.shapePositionYInput || !this.shapeWidthInput || !this.shapeHeightInput) return;
        this.shapeColorInput.value = simpleShape.color;
        this.shapeColor!.style.backgroundColor = simpleShape.color;
        this.setShapePositions(simpleShape.positionX, simpleShape.positionY);
    }

    private setShapePositions(x: number, y: number) {
        if (this.shapePositionXInput && this.shapePositionYInput) {
            this.shapePositionXInput.value = Math.round(x).toString();
            this.shapePositionYInput.value = Math.round(y).toString();
        }
    }

    private setShapeScale(width: number, height: number, rotation: number) {
        if (this.shapeWidthInput && this.shapeHeightInput && this.shapeRotationInput) {
            this.shapeWidthInput.value = Math.round(width).toString();
            this.shapeHeightInput.value = Math.round(height).toString();
            this.shapeRotationInput.value = Math.round(rotation).toString();
        }
    }

    // Send a custom event when a shape is selected
    private dispatchShapeSelected(node: Konva.Node) {
        const event = new CustomEvent('shapeSelected', {
            detail: {
                shapeId: node._id,
                color: node.attrs.fill,
                positionX: node.x(),
                positionY: node.y(),
            },
        });
        this.stage.container()?.dispatchEvent(event);
    }

    // Animation system
    public playAnimation(data: any) {

        const propToAttr = {
            positionX: "x",
            positionY: "y",
            width: "width",
            height: "height",
            rotation: "rotation",
        } as const;

        type Prop = keyof typeof propToAttr;

        for (const shape of this.shapes) {
            const updates: Record<string, number> = {};

            for (const prop of Object.keys(propToAttr) as Prop[]) {

                // console.log("prop", prop)
                const subPoints = shape.attrs.subPoints[prop];
                if (!subPoints) continue;

                for (const sp of subPoints) {
                    if (sp.startTime === data.currentTime) {
                        const attr = propToAttr[prop];
                        updates[attr] = sp.value;
                    }
                }
            }

            // Only call once
            if (Object.keys(updates).length) {
                shape.setAttrs(updates);  // shape.setAttrs({x: 5, y: 10, ...})
            }
        }
    }

    public stopAnimation() {
        if (this.anim) {
            this.anim.stop();
            this.anim = null;
        }
    }

    public checkExistPoint(node: Konva.Node) {
        if (node instanceof Konva.Shape) {

            console.log("node id:", node.id());
            //
            // const shape = this.shapes.find(shape => String(shape.id) === String(node.id()));
            // if (shape)
            //     this.onTransformed?.(shape);
            //
            //
            // this.onTransformed?.(node);

        } else {
            console.warn("Not a node:", node);
        }
    }

    public addPoint(point: TTransformation) {
        const node: Konva.Node | undefined = this.shapes.find((s: any) => s.id() === point.shapeId);

        if (!node) return;

        const newPoint = {
            ...point,
            properties: {
                positionX: node.x(),
                positionY: node.y(),
                width: node.width(),
                height: node.height(),
                rotation: node.rotation(),
            },
        };

        node.attrs.points.push(newPoint);

        node.attrs.points.sort((a: TTransformation, b: TTransformation) => a.start!.getTime() - b.start!.getTime());

        this.calcSubPoints(node, point.propType);
    }

    public removePoint(shapeId: string, pointId: string) {
        const node: Konva.Node | undefined = this.shapes.find((s: any) => s.id() === shapeId);
        if (!node) return;

        const points = node.attrs.points as TTransformation[];
        const index = points.findIndex(p => p.id === pointId);

        // If not found → stop
        if (index === -1) return;

        const removedPoint = points[index];

        // Remove the point
        points.splice(index, 1);

        // Recalculate sub-points only for that property type
        if (removedPoint.propType) {
            this.calcSubPoints(node, removedPoint.propType);
        }
    }

    // public updatePoint(point: TTransformation, nodeValue: number) {
    //
    //     const node: Konva.Node | undefined = this.shapes.find((s: any) => s.id() === point.shapeId);
    //     if (!node) return;
    //
    //
    //     const foundPoint = node.attrs.points.find((p: TTransformation) => p.id === point.id);
    //     foundPoint.properties[point.type] = nodeValue
    //
    //     // console.log("foundPoint", foundPoint)
    //
    //     this.calcSubPoints(node, point.type);
    // }

    public updatePoint(props: any) {
        // props = {
        //     positionX: {point:currentPoint, value:nodeValue},
        //     positionY: {point:currentPoint, value:nodeValue},
        //     ...
        // }

        const node = this.tr.nodes()[0];
        if (!node) return;

        const {points, subPoints} = node.attrs;

        const findCurrentPoint = (point: TTransformation) =>
            points.findIndex(
                (p: TTransformation) =>
                    p.id === point.id
            );

        for (const type of Object.keys(props) as (keyof typeof props)[]) {

            const point = props[type].point
            const value = props[type].value
            if (point) {

                const foundPointIndex = findCurrentPoint(point)
                points[foundPointIndex].properties[type] = value;

                this.calcSubPoints(node, point.type);
            }
        }
    }

    private calcSubPoints(node: Konva.Node, pointType: TTransformPointType) {
        const fps = 25;
        const msPerFrame = 1000 / fps;

        const points = node.attrs.points.filter(
            (p: TTransformation) => p.propType === pointType);


        // Prepare subPoints array
        node.attrs.subPoints[pointType] = [];
        if (points.length < 2) return;

        // Map property to actual numeric value
        const propGetter = (p: TTransformation): number => {
            const v = p.properties?.[pointType];
            if (v === undefined) {
                throw new Error(`Missing property "${pointType}" in transformation point`);
            }
            return v;
        };

        for (let i = 1; i < points.length; i++) {
            const start = points[i - 1];
            const end = points[i];

            const startTime = start.start.getTime();
            const endTime = end.start.getTime();
            const durationMs = endTime - startTime;
            const frameCount = Math.max(1, Math.round(durationMs / msPerFrame));


            const startVal = propGetter(start);
            const endVal = propGetter(end);

            for (let frame = 0; frame <= frameCount; frame++) {
                const t = frame / frameCount;

                const subPoint = {
                    value: this.lerp(startVal, endVal, t),
                    type: pointType,
                    id: `sub-${pointType}-${startTime}-${frame}`, // unique + readable
                    startTime: startTime + frame * msPerFrame,
                };

                node.attrs.subPoints[pointType].push(subPoint);
            }
        }

        // node.attrs.subPoints.sort((a: any, b: any) => a.startTime - b.startTime);

    }

    // private calcSubPoints2(node: Konva.Node) {
    //     const fps = 25;
    //     const msPerFrame = 1000 / fps;
    //     const { points, subPoints } = node.attrs;
    //
    //     const properties = {
    //         positionX: () => Math.round(node.x()),
    //         positionY: () => Math.round(node.y()),
    //         width: () => Math.round(node.width() * node.scaleX()),
    //         height: () => Math.round(node.height() * node.scaleY()),
    //         rotation: () => Math.round(node.rotation()),
    //     } as const;
    //
    //     const findCurrentPoint = (type: keyof typeof properties) =>
    //         points.find(
    //             (p: TTransformation) =>
    //                 p.type === type && p.start?.getTime() === currentTimestamp
    //         );
    //
    //     for (const type of Object.keys(properties) as (keyof typeof properties)[]) {
    //         const currentPoint = findCurrentPoint(type);
    //     }
    // }

    private lerp(a: number, b: number, t: number): number {

        // t=0      a=10,b=30 ->     30
        // t=0.5    a=10,b=30 ->     20
        // t=1      a=10,b=30 ->     10
        // --------------------------------
        // t=0      a=30,b=10 ->     10
        // t=0.5    a=30,b=10 ->     20
        // t=1      a=30,b=10 ->     30

        return Math.round(a + (b - a) * t);
    }
}
