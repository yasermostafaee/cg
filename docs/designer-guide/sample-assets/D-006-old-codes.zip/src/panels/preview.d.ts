export type TShapeProps = {
    shapeId: string
    color: string
    positionX: number
    positionY: number
    width: number
    height: number
}