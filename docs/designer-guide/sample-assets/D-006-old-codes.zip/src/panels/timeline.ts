import {Timeline} from 'vis-timeline';
import {DataSet} from 'vis-data';
import type {
    TTransformGroup,
    TPropsGroup,
    TGroup,
    TTransformation
} from "./timeline.d";
import Konva from "konva";
import {TTransformPointType} from "./timeline.d";

interface TimelineClassType {
    containerId: string,
    itemsData?: any[],
    fps?: number,
    minDate?: Date,
    maxDate?: Date,
    onTimelineUpdating: (data: any) => void;
    onTimelineStop: () => void;
    onTimelineAddPoint: (data: TTransformation) => void;
    onTimelineRemovePoint: (shapeId: string, pointId: string) => void;
    onTimelineUpdatePoint: (props: any) => void;
}

export default class TimelineClass {
    private readonly container: HTMLElement;
    private readonly timeline: Timeline;
    private readonly items: DataSet<any>;
    private readonly groups: DataSet<any>;
    private readonly minDate: Date;
    private readonly maxDate: Date;
    private readonly fps: number;
    private readonly frameDuration: number;
    private timelineTimer: number | null = null;
    private intervalTimer: number | null = null;
    private readonly onTimelineUpdating: (data: any) => void;
    private readonly onTimelineStop: () => void;
    private readonly onTimelineAddPoint: (point: TTransformation) => void;
    private readonly onTimelineRemovePoint: (shapeId: string, pointId: string) => void;
    private readonly onTimelineUpdatePoint: (props: any) => void;

    private groupIdCounter = 1;
    private propIdCounter = 1000;
    private transformIdCounter = 2000;

    constructor({
                    containerId,
                    itemsData,
                    fps = 25,
                    minDate,
                    maxDate,
                    onTimelineUpdating,
                    onTimelineStop,
                    onTimelineAddPoint,
                    onTimelineRemovePoint,
                    onTimelineUpdatePoint,
                }: TimelineClassType) {
        this.container = document.getElementById(containerId)!;
        this.fps = fps;
        this.frameDuration = 1000 / this.fps; // 40ms
        this.minDate = minDate || new Date(0);
        this.maxDate = maxDate || new Date(this.minDate.getTime() + 60 * 1000); // default 1 min
        this.items = new DataSet(itemsData || []);

        this.groups = new DataSet([]);

        this.onTimelineUpdating = onTimelineUpdating;
        this.onTimelineStop = onTimelineStop;
        this.onTimelineAddPoint = onTimelineAddPoint;
        this.onTimelineRemovePoint = onTimelineRemovePoint;
        this.onTimelineUpdatePoint = onTimelineUpdatePoint;
        const options: any = this.getOptions();
        this.timeline = new Timeline(this.container, this.items, this.groups, options);

        // Add custom time bar
        this.timeline.addCustomTime(new Date(0), "timeBarIndex");
        this.listener()
    }

    private getOptions() {

        const self = this

        const frameDuration = self.frameDuration // 40ms

        return {
            width: '100%',
            height: '100%',
            min: this.minDate,
            max: this.maxDate,
            editable: {
                add: false,
                updateTime: true,
                updateGroup: false,
                remove: false,
            },
            selectable: true,
            multiselect: false,
            orientation: {axis: 'top', item: 'top'},
            showCurrentTime: false,
            showMajorLabels: true,
            showMinorLabels: true,
            stack: false,
            margin: {item: 5},
            locale: 'en',
            zoomMin: frameDuration,   // کمترین فاصله بین خطوط = یک فریم
            // zoomMax: frameDuration * 10, // مثلا فاصله 10 فریم بیشتر شود
            snap: (date: any) => {
                // snap to nearest frame
                const time = date.getTime();
                const snappedTime = Math.round(time / frameDuration) * frameDuration;
                return new Date(snappedTime);
            },
            // format: still use normal string for Moment.js parsing
            format: {
                minorLabels: 'ss.SSS', // second + millisecond
                majorLabels: 'HH:mm:ss',
            },
            groupOrder: 'order',
            dataAttributes: 'all',
            onMoving: (item: any, callback: any) => this.onItemMoving(item, callback),

            groupTemplate: function (group: any) {

                const container = document.createElement("div");
                const label = document.createElement("span");
                label.textContent = group.content + " ";
                container.appendChild(label); // ✅ inside container


                if (group?.treeLevel === 3) {

                    const add = document.createElement("button");
                    add.textContent = "";
                    // add.style.fontSize = "small";
                    add.className = "addPointButton";
                    add.dataset.groupId = group.id.toString();

                    add.addEventListener("click", () => {
                        // self.groups.update({ id: group.id, visible: false });
                        const point: TTransformation = {
                            id: `tPoint-${crypto.randomUUID()}`,
                            groupId: group.id,
                            propType: group.content,
                            mainGroupId: group.mainGroupId,
                            start: self.timeline.getCustomTime("timeBarIndex"),
                            shapeId: self.findShapeId(group.mainGroupId),
                        }
                        self.addPointToGroup(point)

                    });
                    container.appendChild(add); // ✅ append inside
                }
                return container;

            },
            onAdd: (item: any, callback: any) => this.onItemAdd(item, callback),

        };
    }

    private onItemMoving(item: any, callback: any) {
        if (this.timelineTimer) window.clearTimeout(this.timelineTimer);

        this.timelineTimer = window.setTimeout(() => {
            console.log("moving item", item);
        }, 50);

        callback(item);
    }

    private onItemAdd(item: any, callback: any) {
        if (this.timelineTimer) window.clearTimeout(this.timelineTimer);

        this.timelineTimer = window.setTimeout(() => {
            console.log("moving item", item);
        }, 50);

        callback(item);
    }

    private listener() {
        const frameDuration = this.frameDuration
        this.timeline.off('timechange')
        this.timeline.on('timechange', (props) => {
            const frameNumber = Math.round((props.time.getTime() - this.minDate.getTime()) / frameDuration);
            const snappedTime = new Date(this.minDate.getTime() + frameNumber * frameDuration);

            // Snap کردن timeBar روی فریم
            this.timeline.setCustomTime(snappedTime, "timeBarIndex");
            this.checkTimeBarChange(snappedTime.getTime());
        });
    }

    public checkTimeBarChange(currentTime: number) {
        const dataToSend = {
            currentTime: currentTime
        };

        this.checkExistPoints(currentTime);
        this.onTimelineUpdating(dataToSend);
    }

    public playTimeBar() {
        if (this.intervalTimer) return this.stopTimeBar()

        // let currentTime1 =  this.timeline.getCustomTime( "timeBarIndex").getTime();
        // let currentTime2 =  this.minDate.getTime();
        let currentTime = this.timeline.getCustomTime("timeBarIndex").getTime() - this.minDate.getTime() || 0;

        const frameDuration = this.frameDuration;
        this.intervalTimer = window.setInterval(() => {
            currentTime += frameDuration; // حرکت frame به frame
            const time = new Date(this.minDate.getTime() + currentTime);

            if (time >= this.maxDate) {
                this.stopTimeBar();
                return;
            }

            this.timeline.setCustomTime(time, "timeBarIndex");
            this.checkTimeBarChange(currentTime);
        }, frameDuration);
    }

    public stopTimeBar() {

        if (this.intervalTimer) {

            window.clearInterval(this.intervalTimer);
            this.intervalTimer = null;
            this.onTimelineStop()
        }
    }

    private checkExistPoints_(currentTime: number) {
        return this.items;
    }

    private checkExistPoints(currentTime: number) {
        const items = this.items.get(); // returns an array of all groups
        // const groups = this.groups.get(); // returns an array of all groups

        const currentPoints = items.filter((item: any) => {
            return item.start.getTime() === currentTime && item.type === "point";
        })

        // group: point.groupId,
        // start: point.start,
        // type: "point",
        // mainGroupId: point.mainGroupId,
        // shapeId: point.shapeId,

        const addPointButtons = document.querySelectorAll(`.addPointButton`);

        addPointButtons.forEach(button => {
            button.classList.remove("exist");
        });

        currentPoints.forEach(point => {
            // const foundGroup = groups.find((group)=> group.id === point.group);
            // if (foundGroup) {
            this.makeAddPointSelected(point.group)
            // }
        })
    }

    public addLayer(shapeId: string) {
        const layerId = this.groupIdCounter++; // unique group ID

        const transformXId = this.transformIdCounter++;
        const transformYId = this.transformIdCounter++;
        const transformWId = this.transformIdCounter++;
        const transformHId = this.transformIdCounter++;
        const transformRId = this.transformIdCounter++;

        const propTransformId = this.propIdCounter++;
        const propFilterId = this.propIdCounter++;

        const transformation: TTransformGroup[] = [
            {id: transformXId, treeLevel: 3, content: "positionX", mainGroupId: layerId},
            {id: transformYId, treeLevel: 3, content: "positionY", mainGroupId: layerId},
            {id: transformWId, treeLevel: 3, content: "width", mainGroupId: layerId},
            {id: transformHId, treeLevel: 3, content: "height", mainGroupId: layerId},
            {id: transformRId, treeLevel: 3, content: "rotation", mainGroupId: layerId},
        ];

        const props: TPropsGroup[] = [
            {
                id: propTransformId,
                treeLevel: 2,
                content: "transform",
                title: "Transform",
                showNested: false,
                nestedGroups: [transformXId, transformYId, transformWId, transformHId, transformRId]
            },
            {id: propFilterId, treeLevel: 2, content: "filter"}
        ];

        const groups: TGroup[] = [
            {
                id: layerId,
                title: "New layer " + layerId,
                content: "New layer",
                treeLevel: 1,
                showNested: false,
                nestedGroups: [propTransformId, propFilterId]
            },
        ];

        const start = this.timeline.getCustomTime("timeBarIndex")
        const end = this.maxDate

        const newItem = {
            // id: Date.now(), // unique ID
            id: shapeId, // the same id with shape in preview.ts
            group: layerId, // 👈 put it in that specific transformation group
            // content: "Point",
            start: start,
            end: end,
            type: "range", // a simple point on the timeline
        };

        this.items.add(newItem);

        this.groups.update(groups);
        this.groups.update(props);
        this.groups.update(transformation);

        // ✅ Force timeline to re-render group templates
        this.timeline.setGroups(this.groups);
    }

    public addPointByTransform(node: Konva.Node) {
        const currentTime = this.timeline.getCustomTime("timeBarIndex");
        const currentTimestamp = currentTime.getTime();
        const {points, subPoints} = node.attrs;

        if (!points.length) return;

        // List of all transform types and their property getters
        const properties = {
            positionX: () => Math.round(node.x()),
            positionY: () => Math.round(node.y()),
            width: () => Math.round(node.width() * node.scaleX()),
            height: () => Math.round(node.height() * node.scaleY()),
            rotation: () => Math.round(node.rotation()),
        } as const;

        const changedExistPointValues: any = {
            //positionX: [currentPoint, nodeValue],
            //positionY: [currentPoint, nodeValue],
            //...
        }

        // Helper: find a point of given type at the current time
        const findCurrentPoint = (type: keyof typeof properties) =>
            points.find(
                (p: TTransformation) =>
                    p.propType === type && p.start?.getTime() === currentTimestamp
            );

        // Helper: find a point of given type at the current time
        const findCurrentPoint2 = (currentPoint: TTransformation, type: keyof typeof properties, nodeValue: number) => {
            // console.log("type", type)
            // console.log("currentPoint.properties?.[type]", currentPoint.properties?.[type])
            // console.log("nodeValue", nodeValue)
            // console.log("-------------------------")
            return nodeValue !== Math.round(currentPoint.properties?.[type] || 0)
        }

        // Helper: find last existing point of a type
        const findLastPoint = (type: keyof typeof properties) =>
            [...points].reverse().find((p: TTransformation) => p.propType === type);

        // Helper: find subPoint difference
        const hasSubPointDifference = (
            type: keyof typeof properties,
            nodeValue: number
        ) => {
            return subPoints?.[type]?.some(
                (sp: any) => {
                    return sp.startTime === currentTimestamp &&
                        nodeValue !== sp.value
                }
            );
        };

        for (const type of Object.keys(properties) as (keyof typeof properties)[]) {
            const currentPoint = findCurrentPoint(type);

            const nodeValue = properties[type](); // node.x() || node.y() , ...

            if (currentPoint) {
                // already has one at this time
                if (findCurrentPoint2(currentPoint, type, nodeValue)) {

                    console.log("must be update: ", type, currentPoint.properties?.[type], nodeValue)

                    changedExistPointValues[type] = {point: currentPoint, value: nodeValue};
                    // this.updatePoint(currentPoint)
                }

                continue;
            }

            const lastPoint = findLastPoint(type);
            if (!lastPoint) continue;


            if (hasSubPointDifference(type, nodeValue) ||
                nodeValue !== Math.round(lastPoint.properties[type])) {

                // console.log("---------------")
                // console.log("type", type)
                // console.log("nodeValue", nodeValue)
                // console.log("lastPoint.properties[type]", lastPoint.properties[type])
                // console.log("---------------")

                const newPoint: TTransformation = {
                    id: `tPoint-${crypto.randomUUID()}`,
                    groupId: lastPoint.groupId,
                    propType: type,
                    mainGroupId: lastPoint.mainGroupId,
                    start: currentTime,
                    shapeId: lastPoint.shapeId,
                };

                console.log(newPoint)
                this.addPointToGroup(newPoint);
            }
        }

        this.updatePoint(changedExistPointValues)

    }

    private updatePoint(props: any) {

        this.onTimelineUpdatePoint(props)
    }

    public addPointToGroup(point: TTransformation) {

        const items = this.items.get(); // returns an array of all groups

        const pointExist = items.find((item: any) => {
            return item.group === point.groupId && item.start.getTime() === point.start?.getTime()
        })

        if (pointExist) {
            this.removePointFromGroup(pointExist.id)
            return
        }

        const newItem = {
            id: point.id, // unique ID
            group: point.groupId, // 👈 put it in that specific transformation group
            // content: "Point",
            start: point.start,
            type: "point", // a simple point on the timeline
            showMajorLabels: false,
            mainGroupId: point.mainGroupId,
            shapeId: point.shapeId,
        };

        // for prevent repetitive id
        this.items.add(newItem);

        this.makeAddPointSelected(String(point.groupId))
        this.onTimelineAddPoint(point)

    }

    public removePointFromGroup(pointId: string) {
        const items = this.items.get();
        const foundPoint = items.find((item: any) => {
            return item.id === pointId
        })

        if (foundPoint){
            this.items.remove(foundPoint.id)
            this.makeAddPointSelected(foundPoint.group, false)
            this.onTimelineRemovePoint(foundPoint.shapeId, foundPoint.id)
        }
    }

    private makeAddPointSelected(groupId: string, selected = true) {
        const addPointButton = document.querySelector(`.addPointButton[data-group-id="${groupId}"]`);

        if (addPointButton) {
            if(selected)
                addPointButton.classList.add("exist");
            else
                addPointButton.classList.remove("exist");
        }
    }

    private findShapeId(mainGroupId: number) {
        const allItems = this.items.get(); // returns an array of all items
        const foundShape = allItems.find((item: any) => item.group === mainGroupId)
        return foundShape?.id
    }
}