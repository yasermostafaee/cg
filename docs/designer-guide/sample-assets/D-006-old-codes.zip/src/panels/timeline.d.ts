export type TTransformGroup = {
    id: number // groupId
    content: TTransformPointType
    title?: string,
    treeLevel: number
    mainGroupId: number
}

export type TTransformPointType = "positionX" | "positionY" | "width" | "height" | "rotation"

export type TPropsGroup = {
    id: number // groupId
    content: "transform" | "filter",
    title?: string,
    treeLevel: number
    showNested?: boolean
    nestedGroups?: number[]
}

export type TGroup = {
    id: number // groupId
    content: string,
    title?: string,
    treeLevel: number
    showNested?: boolean
    nestedGroups?: number[]
}

export type TTransformation = {
    id: string
    groupId: number // groupId
    propType: TTransformPointType
    start?: Date,
    treeLevel?: number
    mainGroupId: number
    shapeId: string
    properties?: TProperties
}

type TProperties = {
    positionX: number;
    positionY: number;
    width: number;
    height: number;
    rotation: number;
};