interface PanelClassType {
    topContainerId: string,
    bottomContainerId: string,
    gutterId: string,
}

export default class PanelClass {
    private topPanel: HTMLElement;
    private bottomPanel: HTMLElement;
    private gutter: HTMLElement;
    private prevY: number = 0;

    constructor( {topContainerId, bottomContainerId, gutterId}: PanelClassType) {
        const topPanelElm = document.getElementById(topContainerId);
        const bottomPanelElm = document.getElementById(bottomContainerId);
        const gutterElm = document.getElementById(gutterId);

        if (!topPanelElm || !bottomPanelElm || !gutterElm) {
            throw new Error("One or more elements not found for PanelResizer");
        }

        this.topPanel = topPanelElm;
        this.bottomPanel = bottomPanelElm;
        this.gutter = gutterElm;

        this.gutter.addEventListener('mousedown', this.onMouseDown);
    }

    private onMouseDown = (e: MouseEvent) => {
        e.preventDefault();

        this.prevY = e.clientY;

        this.gutter.classList.add("is-dragging");

        window.addEventListener('mousemove', this.onMouseMove);
        window.addEventListener('mouseup', this.onMouseUp);
    }

    private onMouseMove = (e: MouseEvent) => {
        const deltaY =  this.prevY - e.clientY;
        this.prevY = e.clientY;

        const topHeight = this.topPanel.getBoundingClientRect().height - deltaY;
        const bottomHeight = this.bottomPanel.getBoundingClientRect().height + deltaY;

        this.topPanel.style.height = `${topHeight}px`;
        this.bottomPanel.style.height = `${bottomHeight}px`;
    }

    private onMouseUp = () => {
        this.gutter.classList.remove("is-dragging");
        window.removeEventListener('mousemove', this.onMouseMove);
        window.removeEventListener('mouseup', this.onMouseUp);
    }
}
